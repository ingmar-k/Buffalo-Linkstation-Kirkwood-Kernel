#!/bin/sh

make USE_OBJDIR=true programs
